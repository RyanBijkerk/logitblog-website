=== Plugin Name ===
Contributors: RBijkerk
Donate link: https://www.paypal.com/cgi-bin/webscr?cmd=_donations&business=Ryan%40logitblog%2ecom&lc=NL&item_name=Tweet%2dFader%20Logitblog&no_note=0&currency_code=EUR&bn=PP%2dDonationsBF%3abtn_donate_SM%2egif%3aNonHostedGuest
Tags: twitter, tweets, tweet-fader, fadein, fadeout, JQuery, Tweet Fader
Tested on: 3.4.2
Stable tag: 1.1.1
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Tweet Fader is a plugin for WordPress to show your latest tweets on your WordPress site. 

== Description ==

Tweet Fader is a plugin for WordPress to show your latest tweets on your WordPress site. 
The Tweet Fader plugin will add a widget that will display the tweets in your sidebar.

The Tweet Fader widget uses JQuery`s fade in/out effect to display single tweets. 
It is a clean and simple look integrated in your WordPress theme.

Please make sure JQuery is enabled in your theme.

== Installation ==

You can install Tweet Fader using the built in WordPress plugin installer. 
Use the add `Upload` option to select the Tweet Fader zip file. 
If you download Tweet Fader manually, make sure it is uploaded to `/wp-content/plugins/Tweet-Fader/`.

Activate Tweet Fader in the `Plugins` admin panel using the `Activate` link.

Go to the `Appearance\Widgets` admin panel and add the Tweet Fader widget to the `Sidebar` or `Footer Area`.

Now the Tweet Fader widget is ready to be configured.

With the current version the following settings can be set:

Widget Header (optional):
The header text display above the widget.

Twitter Name (required):
The name of your Twitter account.

Number of Tweets (required):
The total amount of tweets that will be displayed.

Interval between Tweets in seconds (optional):
The amount of seconds until the next tweet will be displayed. When the option is not set it will be 10 seconds.

== Requirements ==

Your theme must support widgets in order to use the Tweet Fader widget.

JQuery must be enabled in your theme. 
When all required Tweet Fader settings are configured and the tweets are not displayed, JQuery is probably not enabled in your theme. 
In order to enable JQuery try to add the following line in the `header.php` under the tag `<head>`:

`<?php wp_enqueue_script('jquery'); ?>`


== Screenshots ==

1. Tweet-fader widget in the sidebar.
2. The tweet-fader widget settings.

== Changelog ==

= 0.1.0 =
* Beta Release

= 1.0 =
* Twitter API updated

= 1.1 =
* Character Support