<?php
/*
Plugin Name: Tweet Fader
Plugin URI: http://www.logitblog.com/?page_id=1673
Description: Show your latest tweets one by one.
Author: Ryan Bijkerk
Version: 1.0
Author URI: http://www.logitblog.com/?page_id=2


    Copyright 2012  Ryan Bijkerk  (ryan@logitblog.com)

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License, version 2, as 
    published by the Free Software Foundation.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/

class Tweet_Fader_Widget extends WP_Widget {
	function __construct() {
		parent::__construct(false, $name = 'Tweet Fader', array( 'description' => 'Show you latest tweets one by one.' ) );
	}
	
	
	/*
	 * Displays the wPidget form in the admin panel
	 */
	function form( $instance ) {
		$screen_header = esc_attr( $instance['screen_header'] );
		$tweet_id = esc_attr( $instance['tweet_id'] );
		$num_tweets = esc_attr( $instance['num_tweets'] );
		$intv_tweets= esc_attr( $instance['intv_tweets'] );
		?>
		<p>
			<label for="<?php echo $this->get_field_id( 'screen_header' ); ?>">Widget Header:</label>
			<input class="widefat" id="<?php echo $this->get_field_id( 'screen_header' ); ?>" name="<?php echo $this->get_field_name( 'screen_header' ); ?>" type="text" value="<?php echo $screen_header; ?>" />
		</p>
		<p>
			<label for="<?php echo $this->get_field_id( 'tweet_id' ); ?>">Twitter Name:</label>
			<input class="widefat" id="<?php echo $this->get_field_id( 'tweet_id' ); ?>" name="<?php echo $this->get_field_name( 'tweet_id' ); ?>" type="text" value="<?php echo $tweet_id; ?>" />
		</p>
		<p>
			<label for="<?php echo $this->get_field_id( 'num_tweets' ); ?>">Number of Tweets:</label>
			<input class="widefat" id="<?php echo $this->get_field_id( 'num_tweets' ); ?>" name="<?php echo $this->get_field_name( 'num_tweets' ); ?>" type="text" value="<?php echo $num_tweets; ?>" />
		</p>
		<p>
			<label for="<?php echo $this->get_field_id( 'intv_tweets' ); ?>">Interval between Tweets in seconds:</label>
			<input class="widefat" id="<?php echo $this->get_field_id( 'intv_tweets' ); ?>" name="<?php echo $this->get_field_name( 'intv_tweets' ); ?>" type="text" value="<?php echo $intv_tweets; ?>" />
		</p>
		
		<?php
	}
	
	/*
	 * Renders the widget in the sidebar
	 */
	function widget( $args, $instance ) {
		echo $args['before_widget'];
		?>
		<h3 class="widget-title"><?php echo $instance['screen_header'];?></h3>
<?php
		tweeting($args, $instance);
		echo $args['after_widget'];
	}

};



// Initialize the widget
add_action( 'widgets_init', create_function( '', 'return register_widget( "Tweet_Fader_Widget" );' ) );
if(!function_exists('tweeting')) {
function tweeting( $args, $instance ) {
	
	if(!function_exists('processLinks')){
	function processLinks($text) {
    $text = utf8_decode( $text );
    $text = preg_replace('@(https?://([-\w\.]+)+(d+)?(/([\w/_\.]*(\?\S+)?)?)?)@', '<a href="$1">$1</a>', $text );
    $text = preg_replace("#(^|[\n ])@([^ \"\t\n\r<]*)#ise", "'\\1<a href=\"http://www.twitter.com/\\2\" >@\\2</a>'", $text);
    $text = preg_replace("#(^|[\n ])\#([^ \"\t\n\r<]*)#ise", "'\\1<a href=\"https://twitter.com/#!/search/%23\\2\" >#\\2</a>'", $text);
    return $text;
    }}
	
	
	if(!function_exists('get_tweets')){
	function get_tweets($username, $count = '10')
	{
    $url = 'http://api.twitter.com/1/statuses/user_timeline/'.urlencode($username).'.json?count='.(int)$count;//Make the url
    $ch = curl_init();//Initialise CURL
    curl_setopt($ch, CURLOPT_URL, $url);//Set the url
    curl_setopt ($ch, CURLOPT_RETURNTRANSFER, 1);//We want the data to return
    curl_setopt ($ch, CURLOPT_CONNECTTIMEOUT, 10);//Of course, we don't want your script to run forever, so set a timeout
    $json = curl_exec($ch);//Execute and get the page
    curl_close($ch);//Close curl connection
	
    $decode = json_decode($json);//Decode the json

    $return = array();
    foreach($decode as $tweet)
    {
        $return[] = processLinks($tweet->text);
        $tweet = $tweet -> text;//And the text to an array
    }

    return $return;//Return the array
	}}
	
	
	$TweetArray = get_tweets($instance['tweet_id'], $instance['num_tweets']);
	
	//set the random id length 
	$random_id_length = 4; 

	//generate a random id encrypt it and store it in $rnd_id 
	$rnd_id = crypt(uniqid(rand(),1)); 

	//to remove any slashes that might have come 
	$rnd_id = strip_tags(stripslashes($rnd_id)); 

	//Removing any . or / and reversing the string 
	$rnd_id = str_replace(".","",$rnd_id); 
	$rnd_id = strrev(str_replace("/","",$rnd_id)); 

	//finally I take the first 10 characters from the $rnd_id 
	$rnd_id = substr($rnd_id,0,$random_id_length); 
	$tweet = "tweet_";
	$rnd_id = $tweet . $rnd_id;
	
	$interval_basic = $instance['intv_tweets'];
	$def_time = "000";
	if (isset($interval_basic)) { $interval_basic = $interval_basic . $def_time;
  } Else
{ $interval_basic = "10000"; }
	?>
		<html>
		<style>
#tweets {
position: relative;
height: 80px;
}

.<?php echo $rnd_id?>{
display: none;
position: absolute;
top:1px;
}
		</style>
		<script type="text/javascript">

jQuery(document).ready(function() {
				var InfiniteRotator =
				{
				init: function()
				{
					//initial fade-in time (in milliseconds)
					var initialFadeIn = 1000;
 
					//interval between items (in milliseconds)
					var itemInterval = <?php echo $interval_basic; ?>
 
					//cross-fade time (in milliseconds)
					var fadeTime = 1000;
 
					//count number of items
					var numberOfItems = jQuery('.<?php echo $rnd_id ?>').length;
 
					//set current item
					var currentItem = 0;
 
					//show first item
					jQuery('.<?php echo $rnd_id ?>').eq(currentItem).delay(1000).fadeTo(initialFadeIn, 1);
 
					//loop through the items
					var infiniteLoop = setInterval(function(){
						jQuery('.<?php echo $rnd_id ?>').eq(currentItem).delay(1000).fadeOut(fadeTime);
						
						if(currentItem == numberOfItems -1){
							currentItem = 0;
						}else{
							currentItem++;
						}

						jQuery('.<?php echo $rnd_id ?>').eq(currentItem).delay(1000).fadeTo(fadeTime, 1);
 
					}, itemInterval);
				}
			};
 
			InfiniteRotator.init();
		});
</script>


	<div id="tweets">
	<?php
	foreach ($TweetArray as $arTweet) {
		echo "<p class=$rnd_id >$arTweet</p>";
	}
	?>
	</div>
	</html>
	<?php
}}
