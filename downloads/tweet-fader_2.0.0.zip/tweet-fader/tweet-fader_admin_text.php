<?php

echo "<h2>" . __( 'Tweet Fader Settings', 'tf_trdom' ) . "</h2>";
echo "<p> In order to use Tweet Fader you need to authorize the Tweet Fader plugin to access you Twitter. This is required to retrieve your Twitter feed.</p>";
echo '<p> For more information please visit the Tweet Fader <a href="http://www.logitblog.com/tooling/tweet-fader">page</a></p>';
?>