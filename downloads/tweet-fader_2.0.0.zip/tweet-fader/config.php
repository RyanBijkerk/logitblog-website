<?php
/* Consumer key from twitter */
$consumer_key = 'QriLBTxNpg1ntgLZnwVDqg'; 
 
/* Consumer Secret from twitter */
$consumer_secret = 'RHWlEiQoqcoUWxExhpnAkc8pGBuh6N5gA1jq8IwXk';

/* Token file from twitter */
$token_file_widget = '/wp-content/plugins/tweet-fader/tmp/token.tf';
$token_file = plugin_dir_path( __FILE__ ) . '/tmp/token.tf';

/* Token file check if config is done from twitter */
$token_config_widget = '/wp-content/plugins/tweet-fader/tmp/config.tf';
$token_config = plugin_dir_path( __FILE__ ) . '/tmp/config.tf';

?>